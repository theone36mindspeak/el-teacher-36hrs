/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI} from '@google/genai';
import {LitElement, css, html, nothing} from 'lit';
import {customElement, state, query} from 'lit/decorators.js';
import {unsafeHTML} from 'lit/directives/unsafe-html.js';
import {marked} from 'marked';

// --- CONSTANTS --- //

const SYSTEM_PROMPT = `
### **Rol y Especialización**

Eres **"El Teacher"**, un asistente conversacional avanzado, diseñado con una especialización profunda en la **enseñanza de inglés profesional**. Tu función primordial es ofrecer una experiencia de aprendizaje altamente personalizada, adaptada meticulosamente al **nivel de proficiencia, área profesional, estilo de aprendizaje y, crucialmente, la inteligencia predominante** de cada estudiante.

Posees un dominio exhaustivo de principios derivados de la **neuropsicología, las inteligencias múltiples (IM), la programación neurolingüística (PNL) y el mindfulness**. Estas disciplinas se integran de manera sinérgica en cada interacción, permitiéndote generar respuestas no solo efectivas y didácticas, sino también intrínsecamente motivadoras y precisamente calibradas a las necesidades cognitivas y emocionales del alumno.

---

### **Restricciones Operativas y Temáticas**

Es imperativo que todas las interacciones se circunscriban estrictamente al ámbito del **inglés profesional**. Esto incluye, pero no se limita a: contenido curricular, vocabulario específico, gramática, fonética y pronunciación, ejercicios prácticos, seguimiento de progreso, simulaciones de escenarios profesionales y cualquier aspecto relacionado con el desarrollo de la fluidez y competencia en inglés.

En caso de que el usuario formule una pregunta o inicie una conversación ajena a estas temáticas, deberás redirigir cortésmente el diálogo hacia el contenido del curso, reforzando tu propósito como especialista en la enseñanza del idioma.

---
### **Contexto de Usuario Actual**
Has completado el cuestionario de diagnóstico con el usuario. Su perfil es el siguiente:
- **Nombre:** {name}
- **Profesión:** {profession}
- **Inteligencia Predominante:** {intelligence}

Utiliza esta información para personalizar cada interacción, aplicando las estrategias pedagógicas correspondientes a su inteligencia predominante, y contextualizando los ejemplos a su área profesional.

---
### **Estrategias Pedagógicas Basadas en Inteligencias Múltiples:**

* **Lingüística:** Priorizar lecturas de contenido relevante, escritura creativa y técnica, debates estructurados y análisis de texto.
* **Musical:** Integrar canciones, ejercicios de ritmo, entonación y pronunciación basada en la musicalidad del idioma.
* **Visual-Espacial:** Emplear mapas mentales, diagramas de flujo, infografías, imágenes contextuales y recursos audiovisuales.
* **Corporal-Kinestésica:** Fomentar actividades físicas, juegos de rol, simulaciones, dramatizaciones y aprendizaje vivencial.
* **Lógico-Matemática:** Explicar la lógica subyacente de las estructuras gramaticales, patrones sintácticos y reglas del idioma.
* **Interpersonal:** Promover el trabajo colaborativo, diálogos simulados, discusiones grupales y escenarios de negociación.
* **Intrapersonal:** Incentivar la reflexión personal, la escritura de diarios de aprendizaje y el establecimiento de metas individuales.
* **Naturalista:** Utilizar analogías con fenómenos naturales, vocabulario relacionado con el medio ambiente y ejemplos extraídos del entorno real.

---

### **Integración de Principios de Neurociencia y Psicología Aplicada:**

* **Neuropsicología Cognitiva:** Aplica principios de neuroplasticidad, mecanismos de memoria (memoria de trabajo, memoria a largo plazo), atención sostenida y funciones ejecutivas. (Ej: "Este ejercicio está diseñado para **activar tu memoria de trabajo**...")
* **Programación Neurolingüística (PNL):** Emplea metáforas potentes, anclajes positivos y reencuadres cognitivos. (Ej: "Imagina el inglés como un **puente que conecta tus habilidades actuales con nuevas oportunidades**...")
* **Mindfulness y Regulación Emocional:** Fomenta la atención plena y la gestión del estrés. (Ej: "Tómate un **instante consciente**, inhala profundamente y permite que esta nueva estructura gramatical se asiente.")

---

### **Directrices de Interacción Continua:**

* **Refuerzo Positivo:** Implementa una comunicación constante de **motivación, validación y reconocimiento** del esfuerzo.
* **Resolución de Dudas Personalizada:** Aborda las consultas con estrategias didácticas específicas, alineadas con su inteligencia y profesión.
* **Fomento de la Autoeficacia:** Refuerza la autoconfianza y celebra cada avance.
`;

const QUESTIONNAIRE = [
  {
    question:
      '**1/8: Preferencia en el Tiempo Libre:** ¿Qué actividad disfrutas más durante tu tiempo de ocio?',
    options: {
      a: 'Lectura o escritura creativa/técnica.',
      b: 'Resolución de problemas lógicos o acertijos complejos.',
      c: 'Diseño gráfico, dibujo técnico, o conceptualización espacial.',
      d: 'Práctica de deportes o actividades que requieran destreza física.',
      e: 'Escucha o interpretación de composiciones musicales.',
      f: 'Interacción social, debate o coordinación de equipos.',
      g: 'Meditación, reflexión introspectiva o análisis personal.',
      h: 'Actividades al aire libre, estudio de la flora/fauna.',
    },
  },
  {
    question:
      '**2/8: Habilidades Destacadas:** ¿En qué tipo de actividades demuestras mayor aptitud?',
    options: {
      a: 'Composición de textos, dominio ortográfico, narración estructurada.',
      b: 'Análisis cuantitativo, resolución de ecuaciones, pensamiento crítico.',
      c: 'Visualización 3D, elaboración de diagramas, orientación espacial.',
      d: 'Coordinación motriz, habilidades manuales, expresión corporal.',
      e: 'Sensibilidad auditiva, composición rítmica, ejecución instrumental.',
      f: 'Liderazgo de grupos, negociación, resolución de conflictos interpersonales.',
      g: 'Autoanálisis, planificación personal, escritura de diarios reflexivos.',
      h: 'Clasificación de especies, observación de ecosistemas, permacultura.',
    },
  },
  {
    question:
      '**3/8: Modalidad de Aprendizaje Preferida:** ¿Cómo asimilas el conocimiento con mayor facilidad?',
    options: {
      a: 'Mediante la lectura extensiva o la producción escrita.',
      b: 'Identificando patrones subyacentes y relaciones lógicas.',
      c: 'A través de recursos visuales: diagramas, gráficos, mapas conceptuales.',
      d: 'Participación activa, experimentación práctica o movimiento físico.',
      e: 'Integrando el ritmo, la melodía o la musicalidad del contenido.',
      f: 'En contextos colaborativos, debates o discusiones grupales.',
      g: 'Por medio de la introspección silenciosa y el autoaprendizaje.',
      h: 'Observando fenómenos naturales o estableciendo analogías con el entorno.',
    },
  },
  {
    question:
      '**4/8: Preferencias Lúdicas:** ¿Qué tipo de juegos eliges con mayor frecuencia?',
    options: {
      a: 'Crucigramas, Scrabble, juegos de palabras.',
      b: 'Sudoku, ajedrez, rompecabezas de lógica.',
      c: 'Construcción con bloques, puzzles visuales, maquetas.',
      d: 'Deportes, juegos de destreza física, charadas.',
      e: 'Karaoke, juegos de adivinanzas musicales, creación de ritmos.',
      f: 'Juegos de rol, actividades de equipo, simulaciones sociales.',
      g: 'Juegos de estrategia individual, acertijos personales.',
      h: 'Juegos al aire libre, actividades de campismo, cuidado de mascotas virtuales/reales.',
    },
  },
  {
    question:
      '**5/8: Auto-Percepción de Aprendizaje:** ¿Qué afirmación te describe mejor?',
    options: {
      a: '"La lectura y la escritura son mis herramientas fundamentales para el conocimiento."',
      b: '"Disfruto desglosar problemas complejos hasta encontrar su solución lógica."',
      c: '"Mi pensamiento se estructura primordialmente a través de imágenes y visualizaciones."',
      d: '"Necesito interactuar físicamente con el contenido para comprenderlo a fondo."',
      e: '"Los ritmos y las melodías son intrínsecos a mi proceso de memorización."',
      f: '"El intercambio de ideas y el trabajo en equipo potencian mi aprendizaje."',
      g: '"Comprendo mis propios procesos mentales y emocionales con facilidad."',
      h: '"Me siento intrínsecamente conectado con el mundo natural y sus procesos."',
    },
  },
  {
    question:
      '**6/8: Expectativas en la Clase de Inglés:** ¿Qué actividad te gustaría integrar en tu aprendizaje de inglés?',
    options: {
      a: 'Análisis y producción de textos académicos o profesionales.',
      b: 'Comprender la estructura lógica y sintáctica subyacente del idioma.',
      c: 'Utilizar infografías, videos didácticos o diagramas de flujo.',
      d: 'Participar en dramatizaciones, role-playing o simulaciones de escenarios.',
      e: 'Aprender mediante canciones, rimas o la entonación rítmica.',
      f: 'Realizar proyectos colaborativos o debates estructurados.',
      g: 'Mantener un diario de aprendizaje reflexivo o crear narrativas personales.',
      h: 'Aplicar vocabulario en contextos de ecología o ciencias naturales.',
    },
  },
  {
    question:
      '**7/8: Asignaturas de Mayor Interés:** ¿Qué materia o tipo de clase disfrutabas más?',
    options: {
      a: 'Lengua y Literatura, Idiomas Extranjeros, Filosofía.',
      b: 'Matemáticas, Física, Química, Lógica.',
      c: 'Artes Plásticas, Diseño, Arquitectura, Geometría Descriptiva.',
      d: 'Educación Física, Danza, Teatro, Deportes.',
      e: 'Educación Musical, Composición, Historia de la Música.',
      f: 'Historia, Sociología, Política, Ética, Liderazgo.',
      g: 'Psicología, Filosofía de la Mente, Autoayuda.',
      h: 'Biología, Ecología, Geografía, Agronomía.',
    },
  },
  {
    question: '**8/8: Habilidad Intrínseca:** ¿Qué te resulta más natural?',
    options: {
      a: 'Articular ideas complejas con precisión lingüística.',
      b: 'Desarrollar argumentos coherentes y razonados.',
      c: 'Construir representaciones mentales vívidas.',
      d: 'Adquirir nuevas destrezas a través de la práctica física.',
      e: 'Reconocer y reproducir patrones melódicos o rítmicos.',
      f: 'Establecer relaciones interpersonales significativas y efectivas.',
      g: 'Ejercer la autoconciencia y la autorregulación emocional.',
      h: 'Interpretar señales del entorno natural y adaptarse a él.',
    },
  },
];

const INTELLIGENCE_MAP = {
  a: 'Lingüística',
  b: 'Lógico-Matemática',
  c: 'Visual-Espacial',
  d: 'Corporal-Kinestésica',
  e: 'Musical',
  f: 'Interpersonal',
  g: 'Intrapersonal',
  h: 'Naturalista',
};

@customElement('el-teacher-chat')
export class ElTeacherChat extends LitElement {
  // --- STYLES --- //
  static styles = css`
    :host {
      display: flex;
      flex-direction: column;
      height: 100%;
      width: 100%;
      background-color: #fff;
      font-family: 'Roboto', sans-serif;
    }

    /* Header */
    header {
      display: flex;
      align-items: center;
      padding: 10px 20px;
      background-color: #f5f5f5;
      border-bottom: 1px solid #ddd;
      flex-shrink: 0;
    }
    .avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background-color: #007bff;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      font-weight: bold;
      margin-right: 15px;
      font-family: 'Montserrat', sans-serif;
    }
    .avatar svg {
      width: 32px;
      height: 32px;
      fill: white;
    }
    .header-info h1 {
      margin: 0;
      font-size: 1.2rem;
      font-weight: 600;
      color: #333;
    }
    .header-info p {
      margin: 0;
      font-size: 0.85rem;
      color: #666;
    }

    /* Message Area */
    .message-area {
      flex-grow: 1;
      overflow-y: auto;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .message {
      display: flex;
      max-width: 75%;
      align-items: flex-end;
      gap: 10px;
    }

    .message-bubble {
      padding: 10px 15px;
      border-radius: 18px;
      line-height: 1.5;
    }

    .message-bubble p:first-child { margin-top: 0; }
    .message-bubble p:last-child { margin-bottom: 0; }
    .message-bubble ul, .message-bubble ol { padding-left: 20px; }


    .message.user {
      align-self: flex-end;
      flex-direction: row-reverse;
    }
    .user .message-bubble {
      background-color: #007bff;
      color: white;
      border-bottom-right-radius: 4px;
    }
    .bot .message-bubble {
      background-color: #e9e9eb;
      color: #333;
      border-bottom-left-radius: 4px;
    }

    /* Typing Indicator */
    .typing-indicator {
      display: flex;
      gap: 4px;
      padding: 12px 15px;
    }
    .typing-indicator span {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background-color: #aaa;
      animation: bounce 1.4s infinite ease-in-out both;
    }
    .typing-indicator span:nth-of-type(1) { animation-delay: -0.32s; }
    .typing-indicator span:nth-of-type(2) { animation-delay: -0.16s; }

    @keyframes bounce {
      0%, 80%, 100% { transform: scale(0); }
      40% { transform: scale(1.0); }
    }

    /* Input Area */
    .input-area {
      display: flex;
      padding: 15px 20px;
      border-top: 1px solid #ddd;
      flex-shrink: 0;
    }
    input[type='text'] {
      flex-grow: 1;
      border: 1px solid #ccc;
      border-radius: 20px;
      padding: 10px 20px;
      font-size: 1rem;
      outline: none;
      transition: border-color 0.2s;
    }
    input[type='text']:focus {
      border-color: #007bff;
    }
    button {
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 50%;
      width: 44px;
      height: 44px;
      margin-left: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.2s;
    }
    button:hover {
      background-color: #0056b3;
    }
    button:disabled {
      background-color: #a0a0a0;
      cursor: not-allowed;
    }
    button svg {
      width: 24px;
      height: 24px;
      fill: white;
    }
  `;

  // --- STATE & PROPERTIES --- //
  @state() messages = [];
  @state() isLoading = true;
  @state() appState = 'INIT';
  @state() userProfile = {name: '', profession: '', intelligence: ''};
  @state() userAnswers = [];
  @state() currentQuestionIndex = 0;

  @query('.message-area') messageArea;
  @query('#userInput') userInput;

  chat;
  ai;

  // --- LIFECYCLE & INITIALIZATION --- //
  constructor() {
    super();
    if (!process.env.API_KEY) {
      this.addMessage('Error: API_KEY environment variable not set.', 'bot');
      console.error('API_KEY environment variable not set.');
      return;
    }
    this.ai = new GoogleGenAI({apiKey: process.env.API_KEY});
  }

  connectedCallback() {
    super.connectedCallback();
    this.initializeBot();
  }

  updated() {
    this.messageArea.scrollTop = this.messageArea.scrollHeight;
  }

  async initializeBot() {
    await this.addBotMessage(
      '¡Hola! Soy **"El Teacher"**, tu asistente personal para el aprendizaje de inglés profesional. Para comenzar y personalizar tu experiencia, ¿podrías decirme tu nombre?',
      500,
    );
    this.appState = 'AWAITING_NAME';
    this.isLoading = false;
  }

  // --- MESSAGE HANDLING --- //
  addMessage(text, sender) {
    const id = this.messages.length;
    const message = {id, text, sender};
    this.messages = [...this.messages, message];
    return id;
  }

  async addBotMessage(text, delay = 1000) {
    this.isLoading = true;
    await new Promise((resolve) => setTimeout(resolve, delay));
    this.addMessage(text, 'bot');
    this.isLoading = false;
  }

  updateMessage(id, text) {
    const newMessages = [...this.messages];
    newMessages[id] = {...newMessages[id], text};
    this.messages = newMessages;
  }

  async handleUserInput(e) {
    e.preventDefault();
    const userInput = this.userInput.value.trim();
    if (userInput === '' || this.isLoading) return;

    this.addMessage(userInput, 'user');
    this.userInput.value = '';
    this.isLoading = true;

    // Route user input based on application state
    switch (this.appState) {
      case 'AWAITING_NAME':
        this.userProfile.name = userInput;
        await this.addBotMessage(
          `¡Un placer, ${this.userProfile.name}! Ahora, cuéntame, ¿cuál es tu actividad profesional o área de especialización?`,
        );
        this.appState = 'AWAITING_PROFESSION';
        break;
      case 'AWAITING_PROFESSION':
        this.userProfile.profession = userInput;
        await this.addBotMessage(
          `Excelente. Para adaptar la enseñanza a tu estilo, te haré un breve cuestionario. Por favor, responde con la letra de la opción que mejor te represente (a, b, c, etc.).`,
        );
        this.appState = 'IN_QUESTIONNAIRE';
        await this.askQuestion(0);
        break;
      case 'IN_QUESTIONNAIRE':
        await this.handleQuestionnaireAnswer(userInput.toLowerCase());
        break;
      case 'TUTORING':
        await this.processTutorRequest(userInput);
        break;
    }
  }

  // --- ONBOARDING & QUESTIONNAIRE --- //
  async askQuestion(index) {
    if (index < QUESTIONNAIRE.length) {
      this.currentQuestionIndex = index;
      const q = QUESTIONNAIRE[index];
      let questionText = `${q.question}<br><br>`;
      for (const [key, value] of Object.entries(q.options)) {
        questionText += `<strong>${key})</strong> ${value}<br>`;
      }
      await this.addBotMessage(questionText);
    } else {
      await this.completeOnboarding();
    }
  }



  async handleQuestionnaireAnswer(answer) {
    const validOptions = Object.keys(QUESTIONNAIRE[this.currentQuestionIndex].options);
    if (validOptions.includes(answer)) {
      this.userAnswers.push(answer);
      await this.askQuestion(this.currentQuestionIndex + 1);
    } else {
      await this.addBotMessage(
        'Por favor, introduce una respuesta válida (una letra de la "a" a la "h").',
        500,
      );
    }
  }

  calculateIntelligence() {
    const counts = this.userAnswers.reduce((acc, value) => {
      acc[value] = (acc[value] || 0) + 1;
      return acc;
    }, {});
    const predominantLetter = Object.keys(counts).reduce((a, b) =>
      counts[a] > counts[b] ? a : b
    );
    return INTELLIGENCE_MAP[predominantLetter];
  }

  async completeOnboarding() {
    this.userProfile.intelligence = this.calculateIntelligence();
    const finalSystemPrompt = SYSTEM_PROMPT.replace('{name}', this.userProfile.name)
      .replace('{profession}', this.userProfile.profession)
      .replace('{intelligence}', this.userProfile.intelligence);

    this.chat = this.ai.chats.create({
        model: 'gemini-2.5-flash',
        config: { systemInstruction: finalSystemPrompt },
    });
    
    await this.addBotMessage(
      `¡Gracias! He determinado que tu inteligencia predominante es **${this.userProfile.intelligence}**. A partir de ahora, adaptaré todos nuestros ejemplos y actividades a tu profesión de **${this.userProfile.profession}** y a tu estilo de aprendizaje único.`,
    );
    await this.addBotMessage(
      `Estoy listo. ¿Qué te gustaría aprender o practicar hoy? Puedes preguntarme sobre gramática, vocabulario, preparación para entrevistas, ¡lo que necesites!`,
    );
    this.appState = 'TUTORING';
  }

  // --- GEMINI CHAT --- //
  async processTutorRequest(userInput) {
    const messageId = this.addMessage('', 'bot');
    
    try {
      const responseStream = await this.chat.sendMessageStream({message: userInput});

      let text = '';
      for await (const chunk of responseStream) {
        text += chunk.text;
        this.updateMessage(messageId, text);
      }
    } catch (error) {
        console.error("Gemini API Error:", error);
        this.updateMessage(messageId, 'Lo siento, he encontrado un error al procesar tu solicitud. Por favor, intenta de nuevo.');
    } finally {
        this.isLoading = false;
    }
  }

  // --- RENDER METHODS --- //
  renderHeader() {
    return html`
      <header>
        <div class="avatar">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z"></path></svg>
        </div>
        <div class="header-info">
          <h1>El Teacher</h1>
          <p>Tu tutor de inglés profesional</p>
        </div>
      </header>
    `;
  }
  
  renderMessages() {
    return html`
     <div class="message-area">
        ${this.messages.map(
          (msg) => html`
            <div class="message ${msg.sender}">
              <div class="message-bubble">
                ${unsafeHTML(marked.parse(msg.text))}
              </div>
            </div>
          `
        )}
        ${this.isLoading ? html`
            <div class="message bot">
                <div class="message-bubble typing-indicator">
                    <span></span><span></span><span></span>
                </div>
            </div>` : nothing
        }
      </div>
    `;
  }

  renderInput() {
    return html`
      <form class="input-area" @submit=${this.handleUserInput}>
        <input
          id="userInput"
          type="text"
          placeholder="Escribe tu mensaje..."
          autocomplete="off"
          .disabled=${this.isLoading}
        />
        <button type="submit" ?disabled=${this.isLoading}>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path></svg>
        </button>
      </form>
    `;
  }

  render() {
    return html`
      ${this.renderHeader()}
      ${this.renderMessages()}
      ${this.renderInput()}
    `;
  }
}